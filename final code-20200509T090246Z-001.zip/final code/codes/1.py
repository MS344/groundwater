# To create a csv with only Registration Number, Latitude and Longitude frmo the file REGISTRATION.txt
import csv
from collections import defaultdict

with open('loc.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["RN", "LAT", "LNG"])
    with open('./REGISTRATION.txt') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['LAT'].count('-')==2 and row['LNG'].count('-')==2:
                l1=row['LAT'].split('-')
                l2=row['LNG'].split('-')
                lat = -1*float(float(l1[0])+( float(l1[1])*60+float(l1[2]) )/3600 )
                lon = float(float(l2[0])+( float(l2[1])*60+float(l2[2]) )/3600 )
                writer.writerow([row['RN'],str(lat), str(lon)])
