#!/bin/bash
python3 1.py
python3 2.py
python3 3.py
python3 4.py
rm loc.csv
rm final_southern_downs.csv
rm final.csv
mv final2.csv final.csv

