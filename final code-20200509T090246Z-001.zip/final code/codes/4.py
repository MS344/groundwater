# To create the csv with all the desired columns 
import pandas as pd
file1 = open('./REGISTRATION.txt', 'r') 
Lines = file1.readlines() 
dict1 = {}
dict2 = {}
for i in Lines:
    temp = i.split(',')
    if temp[9]!='':
        dict1[temp[0]] = temp[9]
f1 = pd.read_csv('./final_southern_downs.csv')
f2 = pd.read_csv('./WATER_QUALITY_FIELD.txt',sep='|')
column_names = ["RN","LAT","LNG","TOP","FACILITY_STATUS","FACILITY_TYPE"]
data = pd.DataFrame(columns = column_names)
for i in Lines:
    # fac_type given full names based on their acronyms
    temp = i.split(',')
    fac_type = ''
    if temp[1] == 'AB':
        fac_type = "Artesian Bore, Condition Unknown"
    elif temp[1] == 'AC':
        fac_type = "Artesian Bore, Ceased to flow"
    elif temp[1] == 'AF':
        fac_type = "Artesian Bore, Controlled flow"
    elif temp[1] == 'AS':
        fac_type = "Artesian Bore, Seasonal flow"
    elif temp[1] == 'AU':
        fac_type = "Artesian Bore, Uncontrolled flow"
    elif temp[1] == 'SF':
        fac_type = "Sub Artesian facility"
    elif temp[1] == 'SW':
        fac_type = "Surface water facility"
    dict2[temp[0]] = fac_type 

for i,j in f1.iterrows():
    # fac_status given full names based on their acronyms
    s1 = str(int(j["RN"])) 
    if s1 in dict1.keys() and s1 in dict2.keys():
        fac_status = ''
        fac_type = dict2[s1]
        if dict1[s1] == "AD":
            fac_status = "Abandoned and destroyed"
        elif dict1[s1] == "AU":
            fac_status = "Abandoned but still usable"
        elif dict1[s1] == "EX":
            fac_status = "Existing"
        elif dict1[s1] == "PR":
            fac_status = "Proposed"
        data = data.append({"RN": s1,"LAT": j["LAT"],"LNG": j["LNG"],"TOP": j["TOP"],"FACILITY_STATUS": fac_status,"FACILITY_TYPE": fac_type},ignore_index = True)

data.to_csv('final2.csv')