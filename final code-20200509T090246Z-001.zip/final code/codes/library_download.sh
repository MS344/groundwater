#!/bin/bash
sudo apt update
sudo apt install python3-pip
sudo pip3 install pandas
