How to run the project:

1. Download the Git repository.
2. Give "run.sh" and "library_download.sh" permission to "Allow executing file as program".
3. Run "library_download.sh".
4. Run "run.sh".
5. A file names final.csv will get created.
6. Go to "https://www.convertcsv.com/csv-to-json.htm" website and convert final.csv to JSON data.

Requirements:

1. Python3.*
2. Ubuntu 18.*
3. Microsoft edge to view the webite "http://www.mylibrawallet.tech/gov_hack/index.html"
