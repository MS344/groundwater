# To create a new csv by adding TOP column with respective values to loc.csv from AQUIFER.txt
import pandas as pd
aqu = pd.read_csv('./AQUIFER.txt',sep='|')
loc = pd.read_csv('./loc.csv')
dict1 = {}
loc["TOP"]=""

# Create a dictionary with RN as keys and TOP as values
for i,j in aqu.iterrows():
    dict1[j["RN"]] =j["TOP"]

# Function to put TOP against correct RN in the new csv 
def func():
    loc1 = loc
    for i,j in loc1.iterrows():
        if j["RN"] in dict1:
            j["TOP"] = dict1[j["RN"]]
    loc1.to_csv('final.csv')

func()