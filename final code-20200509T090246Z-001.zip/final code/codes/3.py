# To create a new csv with Bore location in and near Southern Downs Regional Council
import pandas as pd
final = pd.read_csv('./final.csv')
column_names = ["RN","LAT","LNG","TOP"]
data = pd.DataFrame(columns = column_names)
count = 0
for i,j in final.iterrows():
    # To delete or keep Bore locations based on Lat, Lng
    if float(j["LAT"])<-27.696747 and float(j["LAT"])>-29.322039 and float(j["LNG"])>150.953782 and float(j["LNG"])<152.789693:
        data = data.append({"RN": j["RN"],"LAT": j["LAT"],"LNG": j["LNG"],"TOP": j["TOP"]},ignore_index = True)
data.to_csv('final_southern_downs.csv')